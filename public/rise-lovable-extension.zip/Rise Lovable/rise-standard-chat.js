// Usa o editor nativo do Lovable como interface, mas mantém o envio no fluxo Rise.
(function () {
  'use strict';

  if (window.top !== window || !location.hostname.endsWith('lovable.dev')) return;

  let enabled = false;
  let sending = false;
  let pending = null;

  function getEditor(target) {
    const form = target?.closest?.('form') || document.querySelector('form#chat-input');
    return form?.querySelector?.('[contenteditable="true"]') || document.querySelector('[contenteditable="true"][role="textbox"]');
  }

  function getText(editor) {
    return String(editor?.innerText || editor?.textContent || '').replace(/\u00a0/g, ' ').trim();
  }

  function isComposerTarget(target) {
    return Boolean(target?.closest?.('form#chat-input, [contenteditable="true"][role="textbox"]'));
  }

  function toast(message, error) {
    const existing = document.getElementById('rise-native-chat-toast');
    if (existing) existing.remove();
    const element = document.createElement('div');
    element.id = 'rise-native-chat-toast';
    element.textContent = message;
    element.style.cssText = [
      'position:fixed', 'left:50%', 'bottom:24px', 'transform:translateX(-50%)',
      'z-index:2147483647', 'padding:12px 16px', 'border-radius:10px',
      'font:600 13px/1.35 -apple-system,BlinkMacSystemFont,Segoe UI,sans-serif',
      'color:#fff', 'background:' + (error ? '#861717' : '#126b42'),
      'box-shadow:0 12px 32px rgba(0,0,0,.32)', 'pointer-events:none'
    ].join(';');
    document.body.appendChild(element);
    setTimeout(() => element.remove(), 3600);
  }

  function sendFromNative(target) {
    if (!enabled || sending) return;
    const editor = getEditor(target);
    const text = getText(editor);
    if (!text) return;
    sending = true;
    const requestId = (crypto.randomUUID ? crypto.randomUUID() : String(Date.now()) + Math.random());
    pending = { requestId, editor };
    toast('Enviando pela Rise Lovable...', false);
    window.postMessage({ type: 'RISE_STANDARD_CHAT_SEND', requestId, text }, '*');
  }

  function intercept(event) {
    if (!enabled || sending) return;
    const target = event.target;
    const isSendButton = target?.closest?.('#chatinput-send-message-button, button[type="submit"]');
    if (!isSendButton) return;
    const editor = getEditor(target);
    if (!getText(editor)) return;
    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation();
    sendFromNative(target);
  }

  document.addEventListener('click', intercept, true);
  document.addEventListener('submit', (event) => {
    if (!enabled || sending) return;
    const editor = getEditor(event.target);
    if (!getText(editor)) return;
    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation();
    sendFromNative(event.target);
  }, true);
  document.addEventListener('keydown', (event) => {
    if (!enabled || sending || event.key !== 'Enter' || event.shiftKey || event.isComposing) return;
    if (!isComposerTarget(event.target)) return;
    const editor = getEditor(event.target);
    if (!editor || !getText(editor)) return;
    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation();
    sendFromNative(event.target);
  }, true);

  window.addEventListener('message', (event) => {
    if (event.source !== window || event.data?.type !== 'RISE_STANDARD_CHAT_RESULT') return;
    if (!pending || event.data.requestId !== pending.requestId) return;
    const current = pending;
    pending = null;
    sending = false;
    if (event.data.success) {
      current.editor.innerHTML = '<p><br class="ProseMirror-trailingBreak"></p>';
      current.editor.dispatchEvent(new Event('input', { bubbles: true }));
      toast('Mensagem enviada pela Rise Lovable.', false);
    } else {
      toast(event.data.error || 'Não foi possível enviar a mensagem.', true);
    }
  });

  chrome.storage.local.get(['rise_standard_chat_enabled'], (stored) => {
    enabled = stored.rise_standard_chat_enabled === true;
  });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.rise_standard_chat_enabled) {
      enabled = changes.rise_standard_chat_enabled.newValue === true;
      if (!enabled) { sending = false; pending = null; }
    }
  });
})();
