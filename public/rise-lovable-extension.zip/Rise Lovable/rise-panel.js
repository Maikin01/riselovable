(function () {
  'use strict';

  try { chrome.storage.local.set({ sidebarCollapsed: false }); } catch (_) {}

  if (typeof window.TS_DEBUG === 'undefined') window.TS_DEBUG = false;
  const tsDebug = (...args) => { if (window.TS_DEBUG) console.log(...args); };
  const SUPABASE_URL = 'https://hyjsaialebpskwfvinig.supabase.co';
  const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imh5anNhaWFsZWJwc2t3ZnZpbmlnIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODQ3MjEyOTcsImV4cCI6MjEwMDI5NzI5N30.xRzxMfr92xxRxMwgNG_0iz9J2Rc6SQV3fLgVKItJgrg';
  const MAX_FILES = 15;
  const MAX_FILE_SIZE = 20 * 1024 * 1024;
  const HISTORY_KEY = 'rise_prompt_history';
  const MAX_HISTORY = 100;
  let spAttachedFiles = [];
  let currentProjectId = '';
  let sending = false;

  const $ = (selector) => document.querySelector(selector);
  const $$ = (selector) => Array.from(document.querySelectorAll(selector));

  function showAlert(title, message) {
    setStatus((title ? title + ': ' : '') + String(message || ''), 'error');
  }

  function setStatus(message, kind) {
    const status = $('#statusBar');
    if (!status) return;
    status.textContent = String(message || '');
    status.className = 'status-bar' + (kind ? ' ' + kind : '');
  }

  function storageGet(keys) {
    return new Promise((resolve) => chrome.storage.local.get(keys, resolve));
  }

  function runtimeMessage(message) {
    return new Promise((resolve, reject) => {
      try {
        chrome.runtime.sendMessage(message, (response) => {
          if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
          resolve(response);
        });
      } catch (error) {
        reject(error);
      }
    });
  }

  async function refreshLovableTokenFromActiveTab() {
  try {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    const tab = tabs && tabs[0];

    if (!tab || !tab.id || !/lovable\.dev/.test(tab.url || "")) {
      return false;
    }

    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      world: "MAIN",
      func: () => {
        window.postMessage({ type: "lovableRequestToken" }, "*");
        setTimeout(() => {
          window.postMessage({ type: "lovableRequestToken" }, "*");
        }, 150);
      }
    });

    await new Promise(resolve => setTimeout(resolve, 900));
    return true;
  } catch (e) {
    console.warn("[SP] Falha ao pedir token atualizado:", e);
    return false;
  }
}

  async function sendPromptNativeViaBackground(mensagem, modoPlano = false, attachedFilesSnapshot) {
  const attachments = Array.isArray(attachedFilesSnapshot) ? attachedFilesSnapshot : spAttachedFiles;
  await refreshLovableTokenFromActiveTab();

  const tabs = await chrome.tabs.query({
    active: true,
    currentWindow: true
  });

  const activeUrl = tabs?.[0]?.url || "";
  const match = activeUrl.match(/projects\/([0-9a-fA-F-]{36})/i);

  const storage = await new Promise((resolve) => {
    chrome.storage.local.get(
      ["lovable_token", "lovable_projectId"],
      resolve
    );
  });

  const projectId = match
    ? match[1]
    : String(storage.lovable_projectId || "").trim();

  if (storage.lovable_projectId && storage.lovable_projectId !== projectId) {
    await chrome.storage.local.remove(["lovable_token", "lovable_projectId"]);
    throw new Error("Projeto mudou. Aguarde sincronizar novamente.");
  }

  let token = String(storage.lovable_token || "").trim();
  token = token.replace(/^Bearer\s+/i, "").trim();

  if (!projectId) {
    throw new Error("Projeto Lovable não identificado.");
  }
  if (!token) {
    throw new Error("Token Lovable não encontrado. Faça login novamente na Lovable.");
  }

  const nativeImageFiles = attachments
    .filter(f => f.is_native_image && f.file_id && !f.uploading && !f.uploadFailed)
    .map(f => ({
      file_id: f.file_id,
      file_name: f.file_name,
      name: f.name || f.file_name,
      file_type: f.file_type,
      type: f.type || f.file_type,
      file_url: f.file_url,
      url: f.url || f.file_url,
    }));

  const tempImageUrls = attachments
    .filter(f => f.is_temp_image && f.download_url && !f.uploading && !f.uploadFailed)
    .map(f => f.download_url);

  const otherFiles = attachments
    .filter(f => !f.is_temp_image && !f.is_native_image && f.file_id && !f.uploading && !f.uploadFailed)
    .map(f => ({ file_id: f.file_id, file_name: f.file_name }));

  const baseMessage = String(mensagem || "").trim();
  const userPrompt = tempImageUrls.length
    ? baseMessage + "\n\nURLs das imagens anexadas:\n" + tempImageUrls.map((url, index) => (index + 1) + ". " + url).join("\n")
    : baseMessage;

  const userMessageId = (self.crypto && crypto.randomUUID) ? crypto.randomUUID() : ('msg_' + Date.now() + '_' + Math.random().toString(36).slice(2));
  // Sender identity is rendered via the chat card header (relabeled from
  // "LOV 3" to "Enviado por LVB Sônico" by overlay.js on lovable.dev).
  // Do NOT prepend it to the body — would show as a duplicate second line.
  const brandedUserPrompt = userPrompt;
  const syntheticMessage = "For the code present, I get the error below.\n\nPlease think step-by-step in order to resolve it.\n```\n" + userPrompt + "\n```\n";

  const payload = {
    id: userMessageId,
    files: [...nativeImageFiles, ...otherFiles],
    selected_elements: [],
    chat_only: false,
    contains_error: true,
    intent: "fix_error",
    message: syntheticMessage,
    message_intent_metadata: {
      fix_error_metadata: {
        errors: [
          { error_type: "runtime", error_message: brandedUserPrompt, build_event_id: "" }
        ]
      }
    },
    error_ids: [],
    runtime_errors: [],
    network_requests: [],
    session_replay: "",
    thread_id: "main",
    view: "preview",
    view_description: "The user is currently viewing the preview. ",
    model: null,
    optimisticImageUrls: []
  };

  // ===== Final payload validation (popup + sidepanel share this builder) =====
  tsDebug("[TS Native Send] spAttachedFiles:", spAttachedFiles);
  tsDebug("[TS Native Send] nativeImageFiles:", nativeImageFiles);
  tsDebug("[TS Native Send] final payload files:", payload.files);
  tsDebug("[TS Native Send] final payload:", payload);

  const hasAttachments = attachments.length > 0;
  if (hasAttachments) {
    const hasInlineRaw = attachments.some(a => a && a.rawFile);
    if (!hasInlineRaw && nativeImageFiles.length === 0 && otherFiles.length === 0 && tempImageUrls.length === 0) {
      showAlert('Erro', 'Imagem anexada, mas não entrou no payload. Verifique o console.');
      throw new Error('Imagem anexada, mas não entrou no payload. Verifique o console.');
    }
  }
  if (nativeImageFiles.length > 0) {
    const allValid = nativeImageFiles.every(item =>
      item.file_id && item.file_name && item.name &&
      item.file_type && item.type &&
      item.file_url && item.url
    );
    if (!allValid) {
      console.warn('[TS Native Send] nativeImageFiles inválidos:', nativeImageFiles);
      showAlert('Erro', 'Imagem anexada, mas não entrou no payload. Verifique o console.');
      throw new Error('Imagem anexada, mas não entrou no payload. Verifique o console.');
    }
  }

  // Envio via Edge Function "send-lovable-prompt" — método inline (LovaSiri).
  // Imagens e ZIPs são enviados como base64 no payload; sem links no prompt.
  const _b64FromFile = (file) => new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => { const s = String(r.result || ''); res(s.split(',')[1] || ''); };
    r.onerror = () => rej(new Error('Falha ao ler arquivo'));
    r.readAsDataURL(file);
  });
  const _inlineFiles = [];
  const _zipFiles = [];
  for (const f of attachments) {
    // Método inline: se existir rawFile, ele deve ser enviado mesmo que o upload antigo
    // por link tenha falhado. ZIP não pode depender do fluxo antigo de signed URL.
    if (f.uploading && !f.rawFile) continue;
    const rf = f.rawFile;
    if (!rf) continue;
    const name = f.file_name || rf.name || 'file';
    const type = (rf.type || f.file_type || '').toLowerCase();
    const isZip = type === 'application/zip' || type === 'application/x-zip-compressed' || /\.zip$/i.test(name);
    let b64 = '';
    try { b64 = await _b64FromFile(rf); } catch(e) { console.warn('[TS Inline Send] Falha ao ler anexo:', name, e); continue; }
    if (!b64) continue;
    if (isZip) {
      _zipFiles.push({ file_name: name, content_type: 'application/x-zip-compressed', data_base64: b64 });
    } else {
      _inlineFiles.push({ name: name, file_name: name, content_type: type || 'image/png', data_base64: b64 });
    }
  }

  const edgePayload = {
    token: token,
    projectId: projectId,
    message: baseMessage,
    modoPlano: Boolean(modoPlano),
    files: _inlineFiles,
    zipFiles: _zipFiles,
    attachedFiles: [],
    current_page: (typeof location !== 'undefined' ? location.pathname : '/') || '/',
    current_viewport_width: (typeof window !== 'undefined' && window.innerWidth) || 1336,
    current_viewport_height: (typeof window !== 'undefined' && window.innerHeight) || 861,
    current_viewport_dpr: (typeof window !== 'undefined' && window.devicePixelRatio) || 1,
  };

  if (attachments.some(f => f && f.rawFile) && (_inlineFiles.length + _zipFiles.length) === 0) {
    showAlert('Erro', 'Arquivo anexado, mas não entrou no payload inline. Verifique o console.');
    throw new Error('Arquivo anexado, mas não entrou no payload inline.');
  }

  const result = await bgFetchRaw(
    SUPABASE_URL + "/functions/v1/send-lovable-prompt",
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "apikey": SUPABASE_ANON_KEY,
        "Authorization": "Bearer " + SUPABASE_ANON_KEY
      },
      body: JSON.stringify(edgePayload)
    }
  );

  const data = (result && result.data) ? result.data : {};
  const upstreamStatus = data.status || result?.status;

  if (upstreamStatus === 401 || upstreamStatus === 403) {
    throw new Error("Sessão Lovable expirada. Recarregue a página e tente novamente.");
  }
  if (upstreamStatus === 402) {
    throw new Error("Você precisa ter pelo menos 1 crédito na sua conta Lovable.");
  }
  if (!result || result.ok !== true || data.ok === false || data.success === false) {
    throw new Error(
      (data && (data.error || data?.data?.message || data?.data?.error)) ||
      "Erro " + (upstreamStatus || result?.status || "desconhecido") + " ao enviar via edge function"
    );
  }

  return {
    success: true,
    method: "edge_send_lovable_prompt",
    data: data.data || data
  };
}

  function bgFetchRaw(url, opts = {}) {
    return new Promise((resolve, reject) => {
      try {
        if (!chrome.runtime || !chrome.runtime.id) return reject(new Error("Extension context invalidated"));
        chrome.runtime.sendMessage({ action: "proxyFetch", url, method: opts.method || "POST", headers: opts.headers || {}, body: opts.body || null }, (resp) => {
          if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
          if (!resp) return reject(new Error("No response"));
          resolve(resp);
        });
      } catch(e) { reject(new Error("Extension context invalidated")); }
    });
  }

  function lovableApiFetch(url, opts = {}) {
    return runtimeMessage({
      action: 'lovableApiFetch',
      url,
      method: opts.method || 'POST',
      headers: opts.headers || {},
      body: opts.body || null
    });
  }

  async function authorizeFeature() {
    if (typeof window.authorizeSend !== 'function') return false;
    try {
      return await window.authorizeSend();
    } catch (error) {
      setStatus(error.message || 'Licença inválida.', 'error');
      return false;
    }
  }

  function projectIdFromUrl(url) {
    const match = String(url || '').match(/\/projects\/([0-9a-fA-F-]{36})/i);
    return match ? match[1] : '';
  }

  async function syncProject() {
    try {
      await refreshLovableTokenFromActiveTab();
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      const stored = await storageGet(['lovable_projectId']);
      currentProjectId = projectIdFromUrl(tabs?.[0]?.url) || String(stored.lovable_projectId || '');
      const shortId = currentProjectId ? currentProjectId.slice(0, 8) + '...' : 'não identificado';
      const project = $('#projectId');
      if (project) project.textContent = currentProjectId || 'Projeto não identificado';
      const sync = $('.sync-project');
      if (sync) sync.textContent = shortId;
      const syncText = $('.sync-text');
      if (syncText && !currentProjectId) syncText.firstChild.textContent = 'Abra um projeto Lovable: ';
      setStatus(currentProjectId ? 'Pronto para usar' : 'Abra um projeto no Lovable', currentProjectId ? '' : 'error');
      renderHistory();
    } catch (error) {
      setStatus('Falha ao sincronizar o projeto.', 'error');
    }
  }

  async function handleSend() {
    if (sending) return;
    const input = $('#messageInput');
    const message = String(input?.value || '').trim();
    if (!message && !spAttachedFiles.length) {
      setStatus('Digite uma mensagem ou anexe um arquivo.', 'error');
      return;
    }
    if (!await authorizeFeature()) return;

    sending = true;
    const button = $('#sendButton');
    const original = button.textContent;
    button.disabled = true;
    button.textContent = 'Enviando...';
    setStatus('Enviando para o Lovable...', 'busy');
    const files = spAttachedFiles.map((file) => ({ ...file }));
    try {
      await sendPromptNativeViaBackground(message, Boolean($('#modoPlano')?.checked), files);
      await addHistory(message || ('Anexos: ' + files.map((file) => file.file_name).join(', ')));
      input.value = '';
      clearAttachments();
      setStatus('Mensagem enviada com sucesso.', 'success');
    } catch (error) {
      setStatus(error?.message || 'Não foi possível enviar.', 'error');
    } finally {
      sending = false;
      button.disabled = false;
      button.textContent = original;
    }
  }

  function addFiles(fileList) {
    const available = MAX_FILES - spAttachedFiles.length;
    const selected = Array.from(fileList || []).slice(0, Math.max(0, available));
    if (!selected.length) {
      setStatus('Limite de ' + MAX_FILES + ' arquivos atingido.', 'error');
      return;
    }
    for (const file of selected) {
      if (file.size > MAX_FILE_SIZE) {
        setStatus(file.name + ' excede o limite de 20 MB.', 'error');
        continue;
      }
      const id = (crypto.randomUUID ? crypto.randomUUID() : Date.now() + '_' + Math.random());
      spAttachedFiles.push({
        file_id: 'local_direct_' + id,
        file_name: file.name,
        name: file.name,
        file_type: file.type || 'application/octet-stream',
        type: file.type || 'application/octet-stream',
        rawFile: file,
        previewUrl: file.type.startsWith('image/') ? URL.createObjectURL(file) : '',
        uploading: false,
        uploadFailed: false,
        is_native_image: false,
        is_temp_image: false
      });
    }
    renderAttachments();
  }

  function removeAttachment(index) {
    const item = spAttachedFiles[index];
    if (item?.previewUrl) URL.revokeObjectURL(item.previewUrl);
    spAttachedFiles.splice(index, 1);
    renderAttachments();
  }

  function clearAttachments() {
    spAttachedFiles.forEach((item) => { if (item.previewUrl) URL.revokeObjectURL(item.previewUrl); });
    spAttachedFiles = [];
    const input = $('#fileInput');
    if (input) input.value = '';
    renderAttachments();
  }

  function renderAttachments() {
    const preview = $('#filePreview');
    if (!preview) return;
    preview.replaceChildren();
    preview.style.display = spAttachedFiles.length ? 'flex' : 'none';
    spAttachedFiles.forEach((file, index) => {
      const item = document.createElement('div');
      item.className = 'preview-item';
      if (file.previewUrl) {
        const image = document.createElement('img');
        image.src = file.previewUrl;
        image.alt = '';
        item.appendChild(image);
      } else {
        const icon = document.createElement('span');
        icon.className = 'file-icon';
        icon.textContent = 'DOC';
        item.appendChild(icon);
      }
      const name = document.createElement('span');
      name.className = 'preview-name';
      name.textContent = file.file_name;
      name.title = file.file_name;
      item.appendChild(name);
      const remove = document.createElement('button');
      remove.type = 'button';
      remove.className = 'remove-file';
      remove.setAttribute('aria-label', 'Remover ' + file.file_name);
      remove.textContent = 'x';
      remove.addEventListener('click', () => removeAttachment(index));
      item.appendChild(remove);
      preview.appendChild(item);
    });
  }

  async function historyItems() {
    const stored = await storageGet([HISTORY_KEY]);
    return Array.isArray(stored[HISTORY_KEY]) ? stored[HISTORY_KEY] : [];
  }

  async function addHistory(message) {
    const all = await historyItems();
    all.unshift({ projectId: currentProjectId, message, createdAt: Date.now() });
    await chrome.storage.local.set({ [HISTORY_KEY]: all.slice(0, MAX_HISTORY) });
    renderHistory();
  }

  async function renderHistory() {
    const messages = $('#messages');
    const empty = $('.history-empty');
    if (!messages || !empty) return;
    const all = await historyItems();
    const items = currentProjectId ? all.filter((item) => item.projectId === currentProjectId) : all;
    messages.replaceChildren();
    messages.classList.toggle('has-history', items.length > 0);
    empty.classList.toggle('is-hidden', items.length > 0);
    if (!items.length) return;
    const list = document.createElement('div');
    list.className = 'history-list';
    for (const item of items) {
      const row = document.createElement('article');
      row.className = 'hist-item hist-user';
      const content = document.createElement('div');
      content.className = 'hist-text';
      content.textContent = item.message;
      const date = document.createElement('time');
      date.className = 'hist-time';
      date.textContent = new Date(item.createdAt).toLocaleString('pt-BR');
      row.append(content, date);
      list.appendChild(row);
    }
    messages.appendChild(list);
  }

  const SHORTCUTS = {
    bugs: 'Analise o projeto, encontre bugs e corrija-os sem alterar comportamentos que já funcionam.',
    refatorar: 'Refatore o código atual para melhorar clareza e manutenção, preservando exatamente o comportamento existente.',
    erros: 'Verifique os erros atuais do projeto, identifique as causas e implemente as correções necessárias.',
    otimizar: 'Otimize o desempenho do projeto sem remover funcionalidades nem mudar a experiência existente.',
    comentarios: 'Revise os comentários do código e deixe apenas comentários úteis, claros e objetivos.',
    seo: 'Faça uma revisão completa de SEO técnico e on-page e aplique as melhorias adequadas.',
    ui: 'Melhore a interface e a responsividade mantendo a identidade visual e todas as funcionalidades.',
    componentes: 'Revise os componentes, elimine duplicações relevantes e preserve todas as APIs e comportamentos.',
    review: 'Faça um code review completo, priorize bugs e riscos, e corrija os problemas encontrados.'
  };

  function chooseShortcut(name) {
    const input = $('#messageInput');
    if (!input || !SHORTCUTS[name]) return;
    input.value = SHORTCUTS[name];
    input.focus();
    input.setSelectionRange(input.value.length, input.value.length);
  }

  function switchTab(name) {
    $$('.tab').forEach((tab) => {
      const active = tab.dataset.tab === name;
      tab.classList.toggle('active', active);
      tab.setAttribute('aria-selected', String(active));
    });
    $$('.tab-panel').forEach((panel) => panel.classList.toggle('hidden', panel.dataset.panel !== name));
    if (name === 'historico') renderHistory();
  }

  async function useStandardChat() {
    if (!await authorizeFeature()) return;
    try {
      const stored = await storageGet(['rise_standard_chat_enabled']);
      const enabled = stored.rise_standard_chat_enabled !== true;
      await chrome.storage.local.set({ rise_standard_chat_enabled: enabled });
      if (window.parent !== window) {
        window.parent.postMessage({ __lovableExt: 'standardChatState', enabled }, '*');
        if (enabled) window.parent.postMessage({ __lovableExt: 'minimize' }, '*');
      } else {
        window.close();
      }
      updateStandardChatButton(enabled);
      setStatus(enabled ? 'Chat padrão ativado.' : 'Chat padrão desativado.', enabled ? 'success' : '');
    } catch (error) {
      setStatus(error.message || 'Não foi possível abrir o chat padrão.', 'error');
    }
  }

  function updateStandardChatButton(enabled) {
    const button = $('.action-red');
    if (!button) return;
    button.textContent = enabled ? 'Desativar Chat Padrão' : 'Usar Chat Padrão';
  }

  async function sendStandardChatMessage(message, requestId) {
    const reply = (success, error) => {
      if (window.parent !== window) {
        window.parent.postMessage({ __lovableExt: 'standardChatResult', requestId, success, error: error || '' }, '*');
      }
    };
    if (!message) return reply(false, 'Mensagem vazia.');
    if (!await authorizeFeature()) return reply(false, 'Licença inválida.');
    try {
      await sendPromptNativeViaBackground(message, Boolean($('#modoPlano')?.checked), []);
      await addHistory(message);
      reply(true);
    } catch (error) {
      reply(false, error?.message || 'Não foi possível enviar a mensagem.');
    }
  }

  function sanitizeFilePath(path) {
    return String(path || '').replace(/^\/+/, '').replace(/\.\.(\/|\\)/g, '');
  }

  async function downloadSource(button) {
    if (!await authorizeFeature()) return;
    button.disabled = true;
    button.classList.add('is-busy');
    const original = button.textContent;
    button.textContent = 'Preparando download...';
    setStatus('Baixando arquivos do projeto...', 'busy');
    try {
      await refreshLovableTokenFromActiveTab();
      const stored = await storageGet(['lovable_token', 'lovable_projectId']);
      const projectId = currentProjectId || String(stored.lovable_projectId || '');
      const token = String(stored.lovable_token || '').replace(/^Bearer\s+/i, '').trim();
      if (!projectId || !token) throw new Error('Projeto não sincronizado.');
      const response = await runtimeMessage({ action: 'downloadProject', projectId, token });
      if (!response?.success) throw new Error(response?.error || 'Falha ao baixar o projeto.');
      const zip = new JSZip();
      for (const file of response.files || []) {
        const path = sanitizeFilePath(file.path || file.name || file.file_path);
        if (!path) continue;
        const content = file.content ?? file.contents ?? file.text ?? '';
        zip.file(path, content);
      }
      const blob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement('a');
      anchor.href = url;
      anchor.download = 'lovable-' + projectId.slice(0, 8) + '.zip';
      anchor.click();
      setTimeout(() => URL.revokeObjectURL(url), 30000);
      setStatus('Código fonte baixado.', 'success');
    } catch (error) {
      setStatus(error.message || 'Falha no download.', 'error');
    } finally {
      button.disabled = false;
      button.classList.remove('is-busy');
      button.textContent = original;
    }
  }

  function ensureLovableBadgeHidden(css) {
    const source = String(css || '');
    if (/#lovable-badge[^{}]*\{[^}]*display\s*:\s*none/i.test(source)) return { changed: false, css: source };
    return { changed: true, css: source.replace(/\s+$/, '') + '\n\n#lovable-badge {\n  display: none !important;\n}\n' };
  }

  async function getProjectCss(projectId, token) {
    const response = await runtimeMessage({ action: 'downloadProject', projectId, token });
    if (!response?.success) throw new Error(response?.error || 'Falha ao carregar o projeto.');
    const known = ['src/styles.css', 'src/index.css', 'src/App.css', 'src/global.css', 'app/globals.css', 'styles/globals.css'];
    const files = response.files || [];
    const pathOf = (file) => sanitizeFilePath(file.path || file.name || file.file_path);
    const contentOf = (file) => file.content ?? file.contents ?? file.text;
    let file = files.find((candidate) => known.includes(pathOf(candidate)));
    if (!file) {
      file = files.find((candidate) => /\.css$/i.test(pathOf(candidate)) && /@tailwind|@import\s+["']tailwindcss|:root/i.test(String(contentOf(candidate) || '')));
    }
    if (!file || typeof contentOf(file) !== 'string') throw new Error('CSS global do projeto não encontrado.');
    return { path: pathOf(file), css: contentOf(file) };
  }

  async function removeWatermark(button) {
    if (!await authorizeFeature()) return;
    const command = 'use css para ocultar completamente o badge lovable (Made with Lovable)';
    button.disabled = true;
    button.classList.add('is-busy');
    const original = button.textContent;
    button.textContent = 'Enviando...';
    setStatus('Enviando comando para remover a marca de água...', 'busy');
    try {
      await sendPromptNativeViaBackground(command, Boolean($('#modoPlano')?.checked), []);
      await addHistory(command);
      setStatus('Comando enviado para o Lovable.', 'success');
    } catch (error) {
      setStatus(error.message || 'Falha ao enviar o comando.', 'error');
    } finally {
      button.disabled = false;
      button.classList.remove('is-busy');
      button.textContent = original;
    }
  }

  function minimize() {
    try {
      chrome.storage.local.set({ sidebarCollapsed: true });
      if (window.parent !== window) window.parent.postMessage({ __lovableExt: 'minimize' }, '*');
      else window.close();
    } catch (_) {}
  }

  function bindPanelDrag() {
    const topbar = $('.topbar');
    if (!topbar || window.parent === window) return;
    let pointerId = null;

    const finish = (event) => {
      if (pointerId === null) return;
      if (event?.pointerId !== undefined && event.pointerId !== pointerId) return;
      try { topbar.releasePointerCapture(pointerId); } catch (_) {}
      pointerId = null;
      topbar.classList.remove('is-dragging');
      window.parent.postMessage({ __lovableExt: 'dragEnd' }, '*');
    };

    topbar.addEventListener('pointerdown', (event) => {
      if (event.button !== 0 && event.pointerType === 'mouse') return;
      if (event.target.closest('button, a, input, textarea, select, label')) return;
      pointerId = event.pointerId;
      topbar.classList.add('is-dragging');
      try { topbar.setPointerCapture(pointerId); } catch (_) {}
      window.parent.postMessage({
        __lovableExt: 'dragStart',
        x: event.screenX,
        y: event.screenY
      }, '*');
      event.preventDefault();
    });

    topbar.addEventListener('mousedown', (event) => {
      if (pointerId !== null || event.button !== 0) return;
      if (event.target.closest('button, a, input, textarea, select, label')) return;
      pointerId = 'mouse';
      topbar.classList.add('is-dragging');
      window.parent.postMessage({
        __lovableExt: 'dragStart',
        x: event.screenX,
        y: event.screenY
      }, '*');
      event.preventDefault();
    });

    topbar.addEventListener('pointermove', (event) => {
      if (pointerId === null || event.pointerId !== pointerId) return;
      window.parent.postMessage({
        __lovableExt: 'dragMove',
        x: event.screenX,
        y: event.screenY
      }, '*');
    });
    topbar.addEventListener('pointerup', finish);
    topbar.addEventListener('pointercancel', finish);
    window.addEventListener('message', (event) => {
      if (event.source !== window.parent || event.data?.__lovableExt !== 'dragEnded') return;
      pointerId = null;
      topbar.classList.remove('is-dragging');
    });
  }

  function bindUi() {
    bindPanelDrag();
    $('#sendButton')?.addEventListener('click', handleSend);
    $('#messageInput')?.addEventListener('keydown', (event) => {
      if (event.key === 'Enter' && !event.shiftKey) {
        event.preventDefault();
        handleSend();
      }
    });
    $('#attachButton')?.addEventListener('click', () => $('#fileInput')?.click());
    $('#fileInput')?.addEventListener('change', (event) => addFiles(event.target.files));
    $('#modoPlano')?.addEventListener('change', async (event) => {
      const enabled = event.target.checked;
      document.body.classList.toggle('plan-mode-on', enabled);
      await chrome.storage.local.set({ rise_modo_plano: enabled });
      setStatus(enabled ? 'Modo plano ativado.' : 'Modo plano desativado.', enabled ? 'success' : '');
    });
    $('#minimizeButton')?.addEventListener('click', minimize);

    $$('.tab').forEach((tab) => tab.addEventListener('click', () => switchTab(tab.dataset.tab)));
    $$('.shortcut-btn').forEach((button) => button.addEventListener('click', () => chooseShortcut(button.dataset.shortcut)));

    const watermark = $('.action-crimson');
    const standard = $('.action-red');
    const download = $('.action-blue');
    watermark?.addEventListener('click', () => removeWatermark(watermark));
    standard?.addEventListener('click', useStandardChat);
    download?.addEventListener('click', () => downloadSource(download));

    const themeToggle = $('#themeToggle');
    themeToggle?.addEventListener('click', async () => {
      const isLight = document.body.classList.toggle('theme-light');
      await chrome.storage.local.set({ rise_theme: isLight ? 'light' : 'dark' });
    });

    const shell = $('.app-shell');
    ['dragenter', 'dragover'].forEach((name) => shell?.addEventListener(name, (event) => {
      event.preventDefault();
      shell.classList.add('drag-over');
    }));
    ['dragleave', 'drop'].forEach((name) => shell?.addEventListener(name, (event) => {
      event.preventDefault();
      shell.classList.remove('drag-over');
      if (name === 'drop') addFiles(event.dataTransfer.files);
    }));

    window.addEventListener('message', (event) => {
      if (event.data?.type !== 'TS_POPUP_ACTION') return;
      if (event.data.action === 'send') handleSend();
      if (event.data.action === 'attach') $('#fileInput')?.click();
    });
    window.addEventListener('message', (event) => {
      if (event.source !== window.parent || event.data?.type !== 'RISE_STANDARD_CHAT_SEND') return;
      sendStandardChatMessage(String(event.data.text || ''), String(event.data.requestId || ''));
    });
  }

  async function initialize() {
    bindUi();
    const stored = await storageGet(['rise_theme', 'rise_modo_plano', 'rise_standard_chat_enabled']);
    document.body.classList.toggle('theme-light', stored.rise_theme === 'light');
    const planToggle = $('#modoPlano');
    if (planToggle) {
      planToggle.checked = stored.rise_modo_plano === true;
      document.body.classList.toggle('plan-mode-on', planToggle.checked);
    }
    updateStandardChatButton(stored.rise_standard_chat_enabled === true);
    await syncProject();
    setInterval(syncProject, 15000);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initialize);
  else initialize();
})();
